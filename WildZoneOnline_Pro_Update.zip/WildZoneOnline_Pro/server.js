const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, "public")));

const WORLD = { width: 2600, height: 1800 };
const rooms = new Map();
const COLORS = ["#63e6be", "#74c0fc", "#ffd43b", "#da77f2", "#ff8787", "#ffa94d", "#f783ac"];
const RESOURCE_NODES = [];
let seed = 53119;
function rand(){ seed = seed * 16807 % 2147483647; return (seed - 1) / 2147483646; }
for(let i=0;i<150;i++) RESOURCE_NODES.push({id:"t"+i,kind:"wood",x:90+rand()*2420,y:90+rand()*1620,hp:3,maxHp:3});
for(let i=0;i<95;i++) RESOURCE_NODES.push({id:"s"+i,kind:"stone",x:70+rand()*2460,y:70+rand()*1660,hp:2,maxHp:2});
const ENEMY_SEEDS = Array.from({length:22},(_,i)=>({id:"e"+i,x:150+rand()*2300,y:150+rand()*1500,hp:45,maxHp:45,kind:i%4===0?"brute":"slime"}));

function cleanName(s){return String(s||"Выживший").replace(/[<>]/g,"").trim().slice(0,16)||"Выживший";}
function makeCode(){let c;do{c=crypto.randomBytes(3).toString("hex").toUpperCase()}while(rooms.has(c));return c;}
function makeRoom(code){return {code,players:new Map(),nodes:RESOURCE_NODES.map(n=>({...n})),enemies:ENEMY_SEEDS.map(e=>({...e})),created:Date.now()};}
function packRoom(room){return {code:room.code,world:WORLD,players:[...room.players.values()].map(({id,name,x,y,color,hp,coins,wood,stone,food,level,xp,weapon,armor,boots,kills})=>({id,name,x,y,color,hp,coins,wood,stone,food,level,xp,weapon,armor,boots,kills})),nodes:room.nodes,enemies:room.enemies};}
function broadcast(room){io.to(room.code).emit("state",packRoom(room));}
function roomOf(sock){return rooms.get(sock.data.roomCode);}
function playerOf(sock){const r=roomOf(sock);return r&&r.players.get(sock.id);}
function notice(sock,msg){sock.emit("notice",msg);}
function addXP(p,amount){p.xp+=amount;let leveled=false;while(p.xp>=p.level*100){p.xp-=p.level*100;p.level++;p.coins+=25;p.hp=100;leveled=true;}return leveled;}
function join(sock,room,name,reply){
 if(sock.data.roomCode) leave(sock);
 if(room.players.size>=12)return reply({ok:false,error:"Комната заполнена (максимум 12 игроков)."});
 const p={id:sock.id,name:cleanName(name),x:180+rand()*220,y:180+rand()*220,color:COLORS[room.players.size%COLORS.length],hp:100,coins:50,wood:0,stone:0,food:3,level:1,xp:0,weapon:1,armor:0,boots:0,kills:0,lastAction:0,lastMove:Date.now()};
 room.players.set(sock.id,p);sock.data.roomCode=room.code;sock.join(room.code);
 reply({ok:true,code:room.code,playerId:sock.id});broadcast(room);sock.to(room.code).emit("notice",p.name+" присоединился");
}
io.on("connection",socket=>{
 socket.on("createRoom",({name}={},reply=()=>{})=>{const code=makeCode(),room=makeRoom(code);rooms.set(code,room);join(socket,room,name,reply);});
 socket.on("joinRoom",({code,name}={},reply=()=>{})=>{const room=rooms.get(String(code||"").trim().toUpperCase());if(!room)return reply({ok:false,error:"Комната не найдена. Проверь код."});join(socket,room,name,reply);});
 socket.on("move",({dx,dy}={})=>{
  const room=roomOf(socket),p=playerOf(socket);if(!room||!p)return;
  const now=Date.now(),dt=Math.max(0,Math.min((now-p.lastMove)/1000,.09));p.lastMove=now;
  dx=Math.max(-1,Math.min(1,Number(dx)||0));dy=Math.max(-1,Math.min(1,Number(dy)||0));const l=Math.hypot(dx,dy)||1;
  const speed=(p.food>0?235:175)+p.boots*24;p.x=Math.max(22,Math.min(WORLD.width-22,p.x+dx/l*speed*dt));p.y=Math.max(22,Math.min(WORLD.height-22,p.y+dy/l*speed*dt));
  socket.emit("position",{x:p.x,y:p.y});
 });
 socket.on("gather",({id}={})=>{
  const room=roomOf(socket),p=playerOf(socket);if(!room||!p)return;
  const node=room.nodes.find(n=>n.id===id);if(!node)return;
  if(Math.hypot(node.x-p.x,node.y-p.y)>75)return notice(socket,"Подойди ближе к ресурсу.");
  if(Date.now()-p.lastAction<250)return;p.lastAction=Date.now();
  node.hp--;if(node.kind==="wood")p.wood+=1;else p.stone+=1;
  if(node.hp<=0)room.nodes=room.nodes.filter(n=>n.id!==id);
  socket.emit("notice",node.kind==="wood"?"+1 дерево":"+1 камень");broadcast(room);
 });
 socket.on("eat",()=>{
  const room=roomOf(socket),p=playerOf(socket);if(!room||!p)return;
  if(p.food<=0)return notice(socket,"Нет еды. Купи её в магазине.");
  if(p.hp>=100)return notice(socket,"Здоровье уже полное.");
  p.food--;p.hp=Math.min(100,p.hp+35);notice(socket,"Ты поел: +35 здоровья");broadcast(room);
 });
 socket.on("attack",()=>{
  const room=roomOf(socket),p=playerOf(socket);if(!room||!p)return;
  if(Date.now()-p.lastAction<380)return;p.lastAction=Date.now();
  const enemy=room.enemies.filter(e=>Math.hypot(e.x-p.x,e.y-p.y)<92).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];
  if(!enemy)return notice(socket,"Враг слишком далеко!");
  enemy.hp-=18+(p.weapon-1)*12;
  if(enemy.hp<=0){room.enemies=room.enemies.filter(e=>e.id!==enemy.id);p.coins+=12+(enemy.kind==="brute"?8:0);p.kills++;const up=addXP(p,30);notice(socket,`Враг побеждён! +${12+(enemy.kind==="brute"?8:0)} монет, +30 XP${up?" · НОВЫЙ УРОВЕНЬ!":""}`);}
  else notice(socket,`Попадание! У врага ${enemy.hp} HP`);
  broadcast(room);
 });
 socket.on("buy",({item}={})=>{
  const room=roomOf(socket),p=playerOf(socket);if(!room||!p)return;
  const items={food:{price:8,label:"Еда"},wood:{price:5,label:"Дерево"},stone:{price:7,label:"Камень"},weapon:{price:80,label:"Улучшение оружия"},armor:{price:65,label:"Броня"},boots:{price:55,label:"Сапоги"}};
  const it=items[item];if(!it)return;
  if(p.coins<it.price)return notice(socket,"Не хватает монет!");
  if(item==="weapon"&&p.weapon>=5)return notice(socket,"Оружие уже максимального уровня.");
  if(item==="armor"&&p.armor>=3)return notice(socket,"Броня уже максимального уровня.");
  if(item==="boots"&&p.boots>=4)return notice(socket,"Сапоги уже максимального уровня.");
  p.coins-=it.price;
  if(item==="food")p.food++;if(item==="wood")p.wood++;if(item==="stone")p.stone++;
  if(item==="weapon")p.weapon++;if(item==="armor")p.armor++;if(item==="boots")p.boots++;
  notice(socket,`Куплено: ${it.label}`);broadcast(room);
 });
 socket.on("craft",({item}={})=>{
  const room=roomOf(socket),p=playerOf(socket);if(!room||!p)return;
  if(item==="medkit"){if(p.wood<2||p.food<1)return notice(socket,"Нужно 2 дерева и 1 еда.");p.wood-=2;p.food--;p.hp=Math.min(100,p.hp+55);notice(socket,"Аптечка создана: +55 здоровья");}
  else if(item==="sword"){if(p.wood<8||p.stone<5)return notice(socket,"Нужно 8 дерева и 5 камня.");p.wood-=8;p.stone-=5;p.weapon=Math.min(5,p.weapon+1);notice(socket,"Оружие улучшено!");}
  else if(item==="camp"){if(p.wood<12||p.stone<8)return notice(socket,"Нужно 12 дерева и 8 камня.");p.wood-=12;p.stone-=8;p.hp=100;notice(socket,"Лагерь поставлен: здоровье восстановлено!");}
  broadcast(room);
 });
 socket.on("leaveRoom",()=>leave(socket));socket.on("disconnect",()=>leave(socket));
 function leave(sock){const code=sock.data.roomCode;if(!code)return;sock.data.roomCode=null;sock.leave(code);const r=rooms.get(code);if(!r)return;const p=r.players.get(sock.id);r.players.delete(sock.id);if(p)io.to(code).emit("notice",p.name+" вышел");if(!r.players.size)rooms.delete(code);else broadcast(r);}
});

// Lightweight enemy AI: nearby enemies chase and hurt players; defeated enemies respawn after a while.
setInterval(()=>{
 for(const room of rooms.values()){
  for(const e of room.enemies){
   let target=null,dist=Infinity;
   for(const p of room.players.values()){const d=Math.hypot(p.x-e.x,p.y-e.y);if(d<dist){dist=d;target=p;}}
   if(target&&dist<260&&dist>32){const dx=target.x-e.x,dy=target.y-e.y,l=Math.hypot(dx,dy)||1;e.x+=dx/l*(e.kind==="brute"?28:45)*.2;e.y+=dy/l*(e.kind==="brute"?28:45)*.2;}
   if(target&&dist<34&&Date.now()-(e.lastHit||0)>1300){e.lastHit=Date.now();const damage=Math.max(3,(e.kind==="brute"?13:7)-target.armor*3);target.hp=Math.max(0,target.hp-damage);if(target.hp===0){target.hp=100;target.x=180+rand()*200;target.y=180+rand()*200;target.coins=Math.max(0,target.coins-15);io.to(room.code).emit("notice",target.name+" был побеждён и потерял 15 монет");}}
  }
  broadcast(room);
 }
},200);
server.listen(PORT,"0.0.0.0",()=>console.log(`WildZone Online: http://localhost:${PORT}`));